//
//  GEOSwift.h
//  GEOSwift
//
//  Created by Andrea Cremaschi on 23/05/15.
//  Copyright (c) 2015 andreacremaschi. All rights reserved.
//

#import <UIKit/UIKit.h>
@import geos;

//! Project version number for GEOSwift.
FOUNDATION_EXPORT double HumboldtVersionNumber;

//! Project version string for GEOSwift.
FOUNDATION_EXPORT const unsigned char HumboldtVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GEOSwift/PublicHeader.h>


