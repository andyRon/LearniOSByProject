## Develop

##### Breaking

##### Enhancements

* Update syntax for Swift 2.2/Xcode 7.3
  [Virgilio Favero Neto](https://github.com/vfn)
  [#21](https://github.com/andreacremaschi/GEOSwift/pull/21)

* Added convenience initializers to create Waypoints and Linestrings from points
  [Andrea Cremaschi](https://github.com/andreacremaschi)
  [f36c3d44b94a4f543cb9f7161cd6910ca6c30b91](https://github.com/andreacremaschi/GEOSwift/commit/f36c3d44b94a4f543cb9f7161cd6910ca6c30b91)

* Restore MapboxGL 
  [Andrea Cremaschi](https://github.com/andreacremaschi)
  [0aab3662ce425d11c72433a699afb82810d7ed71](https://github.com/andreacremaschi/GEOSwift/commit/0aab3662ce425d11c72433a699afb82810d7ed71)

* Added 'covers' and 'nearestPoint' to Geometry, made constructor for Coordinate public
  [David Ganster](https://github.com/davidganster)
  [#18](https://github.com/andreacremaschi/GEOSwift/pull/18)


